$(document).ready(function(){
    $('.clear.example .button').on('click', function () {
        $('.clear.example .ui.dropdown').dropdown('clear');
    });
});